package jp.mikio.mobilelinelogger.v2

import android.Manifest
import android.app.Activity
import android.content.*
import android.content.pm.PackageManager
import android.graphics.*
import android.location.Location
import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polyline
import java.io.File
import kotlin.math.*

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private lateinit var live: TextView
    private lateinit var saveInfo: TextView
    private lateinit var name: EditText
    private lateinit var interval: Spinner
    private lateinit var detail: Switch
    private lateinit var ping: Switch
    private lateinit var osm: Switch
    private lateinit var trajectory: Switch
    private lateinit var screenOn: Switch
    private lateinit var start: Button
    private lateinit var trailButton: Button
    private val prefs by lazy { getSharedPreferences("logger", MODE_PRIVATE) }

    private val receiver = object: BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) { refresh() }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Configuration.getInstance().userAgentValue = packageName
        buildUi(); requestPermissions(); refresh()
    }

    override fun onResume() {
        super.onResume()
        registerReceiver(receiver, IntentFilter(LoggerService.ACTION_STATE), RECEIVER_NOT_EXPORTED)
        refresh()
    }
    override fun onPause() { try { unregisterReceiver(receiver) } catch (_:Exception){}; super.onPause() }

    private fun buildUi() {
        val scroll=ScrollView(this)
        root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(28,24,28,28) }
        fun tv(t:String, sz:Float=16f)=TextView(this).apply { text=t; textSize=sz; setTextColor(Color.rgb(35,35,35)); setPadding(0,8,0,8) }
        val title=tv("携帯回線ロガー v2",27f)
        status=tv("",21f)
        live=tv("",16f)
        saveInfo=tv("",14f)
        name=EditText(this).apply { hint="記録名（例：ラクダ03）"; textSize=18f }
        interval=Spinner(this).apply {
            adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,listOf("省電力 10秒","標準 5秒","詳細調査 1秒"));setSelection(1)
        }
        detail=Switch(this).apply{text="詳細なセル情報を取得"}
        ping=Switch(this).apply{text="通信確認（電池消費増）"}
        trajectory=Switch(this).apply{text="リアルタイム軌跡";isChecked=true}
        osm=Switch(this).apply{text="軌跡の背景にOSMを表示（通信・電池消費増）";isChecked=false}
        screenOn=Switch(this).apply{text="記録中は画面を消灯しない"}
        trailButton=Button(this).apply{text="軌跡を表示";setOnClickListener{startActivity(Intent(this@MainActivity,TrailActivity::class.java))}}
        start=Button(this).apply{text="記録開始";textSize=20f;setOnClickListener{toggle()}}
        val note=tv("CSVは記録中に逐次自動保存。通常は5秒ごと、圏外開始・復帰・停止時は即時反映します。異常終了したログは次回起動時に復旧し、GPX・KML・概要TXTを生成します。",14f)
        listOf(title,status,live,saveInfo,name,interval,detail,ping,trajectory,osm,screenOn,trailButton,start,note).forEach{root.addView(it,LinearLayout.LayoutParams(-1,-2))}
        scroll.addView(root);setContentView(scroll)
    }

    private fun requestPermissions(){
        val p=mutableListOf(Manifest.permission.READ_PHONE_STATE,Manifest.permission.ACCESS_FINE_LOCATION)
        if(android.os.Build.VERSION.SDK_INT>=33)p.add(Manifest.permission.POST_NOTIFICATIONS)
        val need=p.filter{ContextCompat.checkSelfPermission(this,it)!=PackageManager.PERMISSION_GRANTED}
        if(need.isNotEmpty())ActivityCompat.requestPermissions(this,need.toTypedArray(),100)
    }

    private fun toggle(){
        if(prefs.getBoolean("running",false)){
            startService(Intent(this,LoggerService::class.java).setAction(LoggerService.ACTION_STOP))
        }else{
            val sec=when(interval.selectedItemPosition){0->10;2->1;else->5}
            val i=Intent(this,LoggerService::class.java).setAction(LoggerService.ACTION_START)
                .putExtra("name",name.text.toString()).putExtra("interval",sec)
                .putExtra("detail",detail.isChecked).putExtra("ping",ping.isChecked)
            prefs.edit().putBoolean("trajectory_enabled",trajectory.isChecked).putBoolean("osm_enabled",osm.isChecked).apply()
            ContextCompat.startForegroundService(this,i)
            if(screenOn.isChecked)window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
        root.postDelayed({refresh()},400)
    }

    private fun refresh(){
        val running=prefs.getBoolean("running",false);val rows=prefs.getLong("rows",0)
        val file=prefs.getString("file","").orEmpty();val path=prefs.getString("path","").orEmpty()
        status.text=if(running)"● 記録中  ${rows}件" else "停止中  ${prefs.getString("last_summary","保存済みログなし")}"
        val s0=prefs.getString("sim0","SIM0: 取得待ち").orEmpty();val s1=prefs.getString("sim1","SIM1: 取得待ち").orEmpty()
        val gps=prefs.getString("gps","GPS: 取得待ち").orEmpty()
        live.text="$s0\n$s1\n$gps"
        saveInfo.text=if(path.isBlank())"保存先：記録開始後に表示" else "保存中ファイル：$file\n保存先：$path\n保存状態：${if(running)"逐次自動保存中" else "保存済み"}"
        val fg=if(running)Color.WHITE else Color.rgb(35,35,35)
        listOf(status,live,saveInfo).forEach{it.setTextColor(fg)}
        root.setBackgroundColor(if(running)Color.rgb(185,31,35) else Color.WHITE)
        start.text=if(running)"記録停止" else "記録開始"
        name.isEnabled=!running;interval.isEnabled=!running;detail.isEnabled=!running;ping.isEnabled=!running
        trajectory.isEnabled=!running;osm.isEnabled=!running
        trailButton.visibility=if(prefs.getBoolean("trajectory_enabled",true))View.VISIBLE else View.GONE
        if(!running)window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }
}

class TrailActivity: Activity(){
    private val prefs by lazy{getSharedPreferences("logger",MODE_PRIVATE)}
    private lateinit var frame:FrameLayout
    private var map:MapView?=null
    private var trail:TrailView?=null
    private val handler=android.os.Handler(android.os.Looper.getMainLooper())
    private val refreshTask=object:Runnable{override fun run(){reload();handler.postDelayed(this,2000)}}

    override fun onCreate(b:Bundle?){super.onCreate(b);build()}
    override fun onResume(){super.onResume();map?.onResume();handler.post(refreshTask)}
    override fun onPause(){handler.removeCallbacks(refreshTask);map?.onPause();super.onPause()}

    private fun build(){
        val outer=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;background=android.graphics.drawable.ColorDrawable(Color.rgb(16,18,20))}
        val bar=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(12,10,12,10)}
        val back=Button(this).apply{text="←";setOnClickListener{finish()}}
        val title=TextView(this).apply{text="リアルタイム軌跡";textSize=21f;setTextColor(Color.WHITE);setPadding(14,0,0,0)}
        bar.addView(back,LinearLayout.LayoutParams(-2,-2));bar.addView(title,LinearLayout.LayoutParams(0,-2,1f))
        frame=FrameLayout(this);outer.addView(bar,LinearLayout.LayoutParams(-1,-2));outer.addView(frame,LinearLayout.LayoutParams(-1,0,1f));setContentView(outer)
        if(prefs.getBoolean("osm_enabled",false)) buildOsm() else buildPlain()
    }
    private fun buildPlain(){trail=TrailView(this);frame.addView(trail,FrameLayout.LayoutParams(-1,-1))}
    private fun buildOsm(){
        map=MapView(this).apply{setTileSource(TileSourceFactory.MAPNIK);setMultiTouchControls(true);controller.setZoom(16.0)}
        frame.addView(map,FrameLayout.LayoutParams(-1,-1))
        val badge=TextView(this).apply{text="OSM背景 / 取得不能時もログ記録は継続";setTextColor(Color.WHITE);setBackgroundColor(0x99000000.toInt());setPadding(12,8,12,8)}
        frame.addView(badge,FrameLayout.LayoutParams(-2,-2,Gravity.TOP or Gravity.START))
    }
    private fun reload(){
        val p=prefs.getString("path",null)?:return;val f=File(p);if(!f.exists())return
        val pts=readPoints(f)
        if(map!=null){
            map!!.overlays.clear()
            if(pts.isNotEmpty()){
                val line=Polyline().apply{outlinePaint.strokeWidth=7f;setPoints(pts.map{GeoPoint(it.lat,it.lon)})}
                map!!.overlays.add(line)
                val last=pts.last();val m=Marker(map).apply{position=GeoPoint(last.lat,last.lon);title="現在地";setAnchor(Marker.ANCHOR_CENTER,Marker.ANCHOR_BOTTOM)}
                map!!.overlays.add(m);map!!.controller.animateTo(m.position)
            }
            map!!.invalidate()
        }else trail?.setPoints(pts)
    }
    data class Pt(val lat:Double,val lon:Double,val state:String,val net:String,val bearing:Float)
    private fun readPoints(f:File):List<Pt>{
        return try{f.useLines{seq->seq.drop(1).mapNotNull{s->val a=parseCsv(s);if(a.size<25)null else{
            val la=a[18].toDoubleOrNull();val lo=a[19].toDoubleOrNull();if(la==null||lo==null)null else Pt(la,lo,a[10],a[9],a[23].toFloatOrNull()?:0f)
        }}.takeLastSafe(4000)}}catch(_:Exception){emptyList()}
    }
    private fun <T> Sequence<T>.takeLastSafe(n:Int):List<T>{val q=java.util.ArrayDeque<T>();for(x in this){if(q.size>=n)q.removeFirst();q.addLast(x)};return q.toList()}
    private fun parseCsv(s:String):List<String>{val out=mutableListOf<String>();val b=StringBuilder();var q=false;var i=0;while(i<s.length){val c=s[i];if(c=='"'){if(q&&i+1<s.length&&s[i+1]=='"'){b.append('"');i++}else q=!q}else if(c==','&&!q){out.add(b.toString());b.clear()}else b.append(c);i++};out.add(b.toString());return out}
}

class TrailView(c:Context):View(c){
    private var pts:List<TrailActivity.Pt> = emptyList()
    private val p=Paint(Paint.ANTI_ALIAS_FLAG)
    fun setPoints(x:List<TrailActivity.Pt>){pts=x;invalidate()}
    override fun onDraw(c:Canvas){
        super.onDraw(c);c.drawColor(Color.rgb(17,20,22));drawGrid(c)
        p.typeface=Typeface.DEFAULT_BOLD;p.textSize=34f;p.color=Color.WHITE
        c.drawText("N",width-70f,55f,p);p.strokeWidth=8f;c.drawLine(width-52f,72f,width-52f,140f,p)
        val arr=Path().apply{moveTo(width-52f,62f);lineTo(width-70f,88f);lineTo(width-34f,88f);close()};c.drawPath(arr,p)
        if(pts.size<2){p.textSize=28f;p.typeface=Typeface.DEFAULT;c.drawText("GPS軌跡を取得するとここに表示します",30f,height/2f,p);return}
        val minLat=pts.minOf{it.lat};val maxLat=pts.maxOf{it.lat};val minLon=pts.minOf{it.lon};val maxLon=pts.maxOf{it.lon}
        val lat0=(minLat+maxLat)/2;val coslat=cos(Math.toRadians(lat0)).coerceAtLeast(.1)
        val dx=(maxLon-minLon)*111320*coslat;val dy=(maxLat-minLat)*110540
        val pad=70f;val sx=(width-2*pad)/max(dx,50.0);val sy=(height-2*pad)/max(dy,50.0);val scale=min(sx,sy)
        fun xy(x:TrailActivity.Pt):Pair<Float,Float>{val xx=pad+((x.lon-minLon)*111320*coslat*scale).toFloat();val yy=height-pad-((x.lat-minLat)*110540*scale).toFloat();return xx to yy}
        p.style=Paint.Style.STROKE;p.strokeWidth=9f;p.strokeCap=Paint.Cap.ROUND
        for(i in 1 until pts.size){val a=pts[i-1];val b=pts[i];val (x1,y1)=xy(a);val(x2,y2)=xy(b);p.color=when{b.state.contains("OUT_OF_SERVICE")||b.state.contains("EMERGENCY")->Color.RED;b.net.contains("3G")||b.net.contains("2G")->Color.YELLOW;else->Color.rgb(48,200,100)};c.drawLine(x1,y1,x2,y2,p)}
        p.style=Paint.Style.FILL;val (cx,cy)=xy(pts.last());p.color=Color.rgb(55,120,240);c.drawCircle(cx,cy,14f,p);p.color=Color.WHITE;p.style=Paint.Style.STROKE;p.strokeWidth=5f;c.drawCircle(cx,cy,18f,p)
        p.style=Paint.Style.FILL;p.textSize=25f;p.typeface=Typeface.DEFAULT
        val meters=niceScale((width*.32/scale).toDouble());val px=(meters*scale).toFloat();val y=height-28f;p.color=Color.WHITE;c.drawRect(28f,y-6,28f+px,y,p);c.drawText(scaleLabel(meters),28f,y-15,p)
    }
    private fun drawGrid(c:Canvas){p.color=Color.rgb(30,35,38);p.strokeWidth=1f;for(x in 0..width step 48)c.drawLine(x.toFloat(),0f,x.toFloat(),height.toFloat(),p);for(y in 0..height step 48)c.drawLine(0f,y.toFloat(),width.toFloat(),y.toFloat(),p)}
    private fun niceScale(m:Double):Double{val raw=max(10.0,m);val pow=10.0.pow(floor(log10(raw)));val n=raw/pow;return (if(n<2)1.0 else if(n<5)2.0 else 5.0)*pow}
    private fun scaleLabel(m:Double)=if(m>=1000)"${(m/1000).toInt()} km" else "${m.toInt()} m"
}
