package jp.mikio.mobilelinelogger.v1

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.location.*
import android.net.*
import android.os.*
import android.telephony.*
import androidx.core.app.ActivityCompat
import java.io.*
import java.net.HttpURLConnection
import java.net.URL
import java.time.*
import java.time.format.DateTimeFormatter
import java.util.concurrent.Executors

class LoggerService : Service() {
    companion object { const val ACTION_START="START"; const val ACTION_STOP="STOP"; const val ACTION_STATE="jp.mikio.mobilelinelogger.STATE" }
    private val handler=Handler(Looper.getMainLooper()); private val io=Executors.newSingleThreadExecutor()
    private val prefs by lazy { getSharedPreferences("logger",MODE_PRIVATE) }
    private var writer:BufferedWriter?=null; private var file:File?=null; private var interval=5000L; private var rows=0L
    private var lastFlush=0L; private var lastLoc:Location?=null; private var detail=false; private var ping=false
    private var prevStates=mutableMapOf<Int,String>(); private var startElapsed=0L
    private val task=object:Runnable{ override fun run(){ capture(); handler.postDelayed(this,interval) } }

    override fun onCreate(){ super.onCreate(); channel(); recoverOld(); startForeground(11, notification("待機中")) }
    override fun onBind(i:Intent?)=null
    override fun onStartCommand(i:Intent?,f:Int,id:Int):Int { when(i?.action){ACTION_STOP->stopLogging();ACTION_START->startLogging(i)}; return START_STICKY }

    private fun startLogging(i:Intent){ if(prefs.getBoolean("running",false)&&writer!=null)return
        interval=i.getIntExtra("interval",5)*1000L; detail=i.getBooleanExtra("detail",false); ping=i.getBooleanExtra("ping",false)
        val n=i.getStringExtra("name")?.trim()?.replace(Regex("[^\\p{L}\\p{N}_-]"),"_")?.take(40).orEmpty()
        val stamp=LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss")); val dir=getExternalFilesDir("logs")?:filesDir
        file=File(dir,"signal_${stamp}${if(n.isBlank())"" else "_$n"}.csv")
        writer=file!!.bufferedWriter(Charsets.UTF_8); writer!!.write(HEADER); writer!!.newLine(); writer!!.flush(); rows=0; startElapsed=SystemClock.elapsedRealtime()
        prefs.edit().putBoolean("running",true).putString("file",file!!.name).putString("path",file!!.absolutePath).putLong("rows",0).apply()
        location(); handler.removeCallbacks(task); handler.post(task); update("記録中")
    }

    private fun capture(){ val now=ZonedDateTime.now(); val elapsed=SystemClock.elapsedRealtime(); val lm=getSystemService(LocationManager::class.java)
        if(ActivityCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED){ lastLoc=lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)?:lastLoc }
        val tm=getSystemService(TelephonyManager::class.java); val subs=getSystemService(SubscriptionManager::class.java)
        val list=try{subs.activeSubscriptionInfoList?:emptyList()}catch(_:Exception){emptyList()}
        if(list.isEmpty()) writeRow(now,elapsed,-1,tm,"NO_SIM") else list.forEach { s -> try { val t=tm.createForSubscriptionId(s.subscriptionId); writeRow(now,elapsed,s.simSlotIndex,t,null) } catch(e:Exception){ writeError(now,elapsed,s.simSlotIndex,e) } }
    }

    private fun writeRow(now:ZonedDateTime, elapsed:Long, slot:Int, tm:TelephonyManager, forced:String?){
        val ss=try{tm.serviceState}catch(_:Exception){null}; val state=forced?:when(ss?.state){ServiceState.STATE_IN_SERVICE->"IN_SERVICE";ServiceState.STATE_OUT_OF_SERVICE->"OUT_OF_SERVICE";ServiceState.STATE_EMERGENCY_ONLY->"EMERGENCY_ONLY";ServiceState.STATE_POWER_OFF->"POWER_OFF";else->"UNKNOWN"}
        val event=when{prevStates[slot]==null->"START"; prevStates[slot]!="OUT_OF_SERVICE"&&state=="OUT_OF_SERVICE"->"OUTAGE_START";prevStates[slot]=="OUT_OF_SERVICE"&&state!="OUT_OF_SERVICE"->"OUTAGE_RECOVERED";else->""}; prevStates[slot]=state
        val cells=try{tm.allCellInfo?:emptyList()}catch(_:Exception){emptyList()}; val reg=cells.firstOrNull{it.isRegistered}?:cells.firstOrNull(); val sig=signal(reg)
        val loc=lastLoc; val age=loc?.let{SystemClock.elapsedRealtime()-it.elapsedRealtimeNanos/1_000_000} ?: -1
        val operator=try{tm.networkOperatorName}catch(_:Exception){""}; val numeric=try{tm.networkOperator}catch(_:Exception){""}; val roaming=try{tm.isNetworkRoaming}catch(_:Exception){false}
        val net=networkName(try{tm.dataNetworkType}catch(_:Exception){0}); val internet=if(ping) connectivity() else ""
        val fields=listOf(now.format(DateTimeFormatter.ISO_OFFSET_DATE_TIME),now.withZoneSameInstant(ZoneOffset.UTC).format(DateTimeFormatter.ISO_INSTANT),now.zone.id,now.offset.toString(),elapsed-startElapsed,slot,csv(operator),numeric,roaming,net,state,event,sig.dbm,sig.rsrp,sig.rsrq,sig.sinr,sig.cell,csv(sig.extra),loc?.latitude?:"",loc?.longitude?:"",loc?.altitude?:"",loc?.accuracy?:"",loc?.speed?:"",loc?.bearing?:"",age,internet,"",Build.MANUFACTURER+" "+Build.MODEL,Build.VERSION.SDK_INT)
        append(fields.joinToString(","), event.isNotBlank())
    }

    private data class S(val dbm:Any="",val rsrp:Any="",val rsrq:Any="",val sinr:Any="",val cell:String="",val extra:String="")
    private fun signal(c:CellInfo?):S=try{when(c){is CellInfoLte->{val s=c.cellSignalStrength; val id=c.cellIdentity; S(s.dbm,s.rsrp,s.rsrq,s.rssnr,"${id.ci}",if(detail)"pci=${id.pci};tac=${id.tac};earfcn=${id.earfcn}" else "")};is CellInfoNr->{val s=c.cellSignalStrength as CellSignalStrengthNr; val id=c.cellIdentity as CellIdentityNr; S(s.dbm,s.ssRsrp,s.ssRsrq,s.ssSinr,"${id.nci}",if(detail)"pci=${id.pci};tac=${id.tac};nrarfcn=${id.nrarfcn}" else "")};is CellInfoWcdma->{val s=c.cellSignalStrength;val id=c.cellIdentity;S(s.dbm,"","","","${id.cid}",if(detail)"psc=${id.psc};lac=${id.lac};uarfcn=${id.uarfcn}" else "")};is CellInfoGsm->{val s=c.cellSignalStrength;val id=c.cellIdentity;S(s.dbm,"","","","${id.cid}",if(detail)"lac=${id.lac};arfcn=${id.arfcn};bsic=${id.bsic}" else "")};else->S()} }catch(_:Exception){S()}
    private fun networkName(n:Int)=when(n){TelephonyManager.NETWORK_TYPE_LTE->"4G_LTE";TelephonyManager.NETWORK_TYPE_NR->"5G_NR";TelephonyManager.NETWORK_TYPE_UMTS,TelephonyManager.NETWORK_TYPE_HSDPA,TelephonyManager.NETWORK_TYPE_HSUPA,TelephonyManager.NETWORK_TYPE_HSPA->"3G_WCDMA";TelephonyManager.NETWORK_TYPE_EDGE->"2G_EDGE";TelephonyManager.NETWORK_TYPE_GPRS->"2G_GPRS";else->"UNKNOWN"}
    private fun connectivity():String=try{val cm=getSystemService(ConnectivityManager::class.java); val n=cm.activeNetwork?:return "NO_INTERNET"; val cap=cm.getNetworkCapabilities(n); if(cap?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)==true)"VALIDATED" else "UNVALIDATED"}catch(_:Exception){"ERROR"}
    private fun csv(s:String)="\""+s.replace("\"","\"\"")+"\""
    private fun append(line:String, urgent:Boolean){ io.execute{try{writer?.write(line);writer?.newLine();rows++;prefs.edit().putLong("rows",rows).apply();val n=SystemClock.elapsedRealtime();if(urgent||n-lastFlush>=5000){writer?.flush();lastFlush=n};sendBroadcast(Intent(ACTION_STATE).setPackage(packageName))}catch(_:Exception){}} }
    private fun writeError(n:ZonedDateTime,e:Long,s:Int,x:Exception){append("${n.format(DateTimeFormatter.ISO_OFFSET_DATE_TIME)},${n.toInstant()},${n.zone.id},${n.offset},${e-startElapsed},$s,,,,,UNKNOWN,ERROR,,,,,,,,,,,,,,,${csv(x.javaClass.simpleName)},${csv(Build.MODEL)},${Build.VERSION.SDK_INT}",true)}

    private fun location(){ if(ActivityCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED)return; val lm=getSystemService(LocationManager::class.java); try{lm.requestLocationUpdates(LocationManager.GPS_PROVIDER,1000,0f,object:LocationListener{override fun onLocationChanged(l:Location){lastLoc=l}},Looper.getMainLooper())}catch(_:Exception){} }
    private fun stopLogging(){ if(!prefs.getBoolean("running",false)){stopSelf();return}; handler.removeCallbacks(task); io.execute{try{writer?.flush();writer?.close()}catch(_:Exception){};writer=null;file?.let{generateDerived(it,false)};prefs.edit().putBoolean("running",false).putString("last_summary","${file?.name} / ${rows}件").apply();sendBroadcast(Intent(ACTION_STATE).setPackage(packageName));stopForeground(STOP_FOREGROUND_REMOVE);stopSelf()} }
    private fun recoverOld(){ if(prefs.getBoolean("running",false)){ val p=prefs.getString("path",null); if(p!=null){val f=File(p);if(f.exists())generateDerived(f,true)};prefs.edit().putBoolean("running",false).putString("last_summary","前回の異常終了ログを復旧しました").apply()} }

    private fun generateDerived(csv:File, abnormal:Boolean){ try{val lines=csv.readLines();if(lines.size<2)return;val base=csv.nameWithoutExtension;val dir=csv.parentFile!!;val pts=lines.drop(1).mapNotNull{parsePoint(it)}
        File(dir,"$base.gpx").bufferedWriter().use{w->w.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?><gpx version=\"1.1\" creator=\"携帯回線ロガーv1\" xmlns=\"http://www.topografix.com/GPX/1/1\"><trk><name>$base</name><trkseg>");pts.forEach{p->w.write("<trkpt lat=\"${p.lat}\" lon=\"${p.lon}\"><time>${p.utc}</time><extensions><slot>${p.slot}</slot><network>${xml(p.net)}</network><state>${xml(p.state)}</state><dbm>${p.dbm}</dbm></extensions></trkpt>")};w.write("</trkseg></trk></gpx>")}
        File(dir,"$base.kml").bufferedWriter().use{w->w.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?><kml xmlns=\"http://www.opengis.net/kml/2.2\"><Document><name>$base</name><Placemark><LineString><coordinates>");pts.forEach{w.write("${it.lon},${it.lat},0 ")};w.write("</coordinates></LineString></Placemark></Document></kml>")}
        File(dir,"${base}_summary.txt").writeText("携帯回線ロガーv1\nファイル: ${csv.name}\nレコード数: ${lines.size-1}\n終了: ${if(abnormal)"異常終了から復旧" else "正常終了"}\nGPX/KML生成済み\n")
    }catch(_:Exception){} }
    private data class P(val utc:String,val slot:String,val net:String,val state:String,val dbm:String,val lat:Double,val lon:Double)
    private fun parsePoint(s:String):P?{val a=parseCsv(s);if(a.size<20)return null;val lat=a[18].toDoubleOrNull()?:return null;val lon=a[19].toDoubleOrNull()?:return null;return P(a[1],a[5],a[9],a[10],a[12],lat,lon)}
    private fun parseCsv(s:String):List<String>{val out=mutableListOf<String>();val b=StringBuilder();var q=false;var i=0;while(i<s.length){val c=s[i];if(c=='\"'){if(q&&i+1<s.length&&s[i+1]=='\"'){b.append('\"');i++}else q=!q}else if(c==','&&!q){out.add(b.toString());b.clear()}else b.append(c);i++};out.add(b.toString());return out}
    private fun xml(s:String)=s.replace("&","&amp;").replace("<","&lt;")
    private fun channel(){val nm=getSystemService(NotificationManager::class.java);nm.createNotificationChannel(NotificationChannel("logger","携帯回線ログ記録",NotificationManager.IMPORTANCE_LOW))}
    private fun notification(t:String)=Notification.Builder(this,"logger").setContentTitle("携帯回線ロガーv1").setContentText(t).setSmallIcon(android.R.drawable.ic_menu_mylocation).setOngoing(true).build()
    private fun update(t:String){getSystemService(NotificationManager::class.java).notify(11,notification(t))}
    override fun onDestroy(){handler.removeCallbacks(task);try{writer?.flush();writer?.close()}catch(_:Exception){};super.onDestroy()}
    private val HEADER="local_time,utc_time,timezone,utc_offset,elapsed_ms,sim_slot,operator,mcc_mnc,roaming,network_type,service_state,event,dbm,rsrp,rsrq,sinr,cell_id,cell_detail,latitude,longitude,altitude_m,accuracy_m,speed_mps,bearing_deg,location_age_ms,internet_state,error,device,android_sdk"
}
