package jp.mikio.mobilelinelogger.v1

import android.Manifest
import android.app.Activity
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private lateinit var name: EditText
    private lateinit var interval: Spinner
    private lateinit var detail: Switch
    private lateinit var ping: Switch
    private lateinit var map: Switch
    private lateinit var screenOn: Switch
    private lateinit var start: Button
    private val prefs by lazy { getSharedPreferences("logger", MODE_PRIVATE) }

    private val receiver = object: BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) { refresh() }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        buildUi(); requestPermissions(); refresh()
    }

    override fun onResume() { super.onResume(); registerReceiver(receiver, IntentFilter(LoggerService.ACTION_STATE), RECEIVER_NOT_EXPORTED); refresh() }
    override fun onPause() { try { unregisterReceiver(receiver) } catch (_:Exception){}; super.onPause() }

    private fun buildUi() {
        root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(32,28,32,28) }
        val title=TextView(this).apply { text="携帯回線ロガーv1"; textSize=26f; setTextColor(Color.BLACK) }
        status=TextView(this).apply { textSize=20f; setPadding(0,18,0,18) }
        name=EditText(this).apply { hint="記録名（例：ラクダ03）" }
        interval=Spinner(this).apply { adapter=ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("省電力 10秒","標準 5秒","詳細調査 1秒")); setSelection(1) }
        detail=Switch(this).apply { text="詳細なセル情報を取得" }
        ping=Switch(this).apply { text="通信確認（Ping相当・電池消費増）" }
        map=Switch(this).apply { text="リアルタイム地図（電池消費増）" }
        screenOn=Switch(this).apply { text="記録中は画面を消灯しない" }
        start=Button(this).apply { text="記録開始"; textSize=20f; setOnClickListener { toggle() } }
        val note=TextView(this).apply { text="CSVは記録中に逐次自動保存。異常終了時も直前まで復旧します。停止時/復旧時にGPX・KML・概要TXTを生成します。"; setPadding(0,20,0,0) }
        listOf(title,status,name,interval,detail,ping,map,screenOn,start,note).forEach { root.addView(it, LinearLayout.LayoutParams(-1,-2)) }
        setContentView(root)
    }

    private fun requestPermissions() {
        val p=mutableListOf(Manifest.permission.READ_PHONE_STATE, Manifest.permission.ACCESS_FINE_LOCATION)
        if(android.os.Build.VERSION.SDK_INT>=33) p.add(Manifest.permission.POST_NOTIFICATIONS)
        val need=p.filter { ContextCompat.checkSelfPermission(this,it)!=PackageManager.PERMISSION_GRANTED }
        if(need.isNotEmpty()) ActivityCompat.requestPermissions(this,need.toTypedArray(),100)
    }

    private fun toggle() {
        if(prefs.getBoolean("running",false)) {
            startService(Intent(this, LoggerService::class.java).setAction(LoggerService.ACTION_STOP))
        } else {
            val sec=when(interval.selectedItemPosition){0->10;2->1;else->5}
            val i=Intent(this,LoggerService::class.java).setAction(LoggerService.ACTION_START)
                .putExtra("name",name.text.toString()).putExtra("interval",sec)
                .putExtra("detail",detail.isChecked).putExtra("ping",ping.isChecked)
            ContextCompat.startForegroundService(this,i)
            if(screenOn.isChecked) window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
        root.postDelayed({refresh()},500)
    }

    private fun refresh() {
        val running=prefs.getBoolean("running",false)
        val rows=prefs.getLong("rows",0)
        status.text=if(running) "● 記録中  ${rows}件\n${prefs.getString("file","")}" else "停止中\n${prefs.getString("last_summary","保存済みログなし")}" 
        status.setTextColor(if(running) Color.WHITE else Color.DKGRAY)
        root.setBackgroundColor(if(running) Color.rgb(180,35,35) else Color.WHITE)
        start.text=if(running) "記録停止" else "記録開始"
        name.isEnabled=!running; interval.isEnabled=!running; detail.isEnabled=!running; ping.isEnabled=!running
        if(!running) window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }
}
