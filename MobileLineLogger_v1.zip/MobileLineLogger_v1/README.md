# 携帯回線ロガーv1

安定性優先のAndroid携帯回線/GPSロガー。

- CSV逐次自動保存（約5秒ごとflush、重要イベント時即flush）
- Foreground Serviceでバックグラウンド記録
- デュアルSIMをSIMスロット別に記録
- LTE/5G/3G、ServiceState、電波強度、Cell情報（任意）
- GPS位置・精度・速度・方位・位置情報の経過時間
- ローカル時刻、UTC、タイムゾーン、UTCオフセット
- 圏外開始/復帰イベント
- 異常終了したCSVを次回起動時に復旧
- 停止/復旧時にGPX・KML・概要TXTを生成
- 省電力10秒 / 標準5秒 / 詳細1秒
- 通信状態確認は任意ON

保存先はAndroidのアプリ専用外部領域 `Android/data/jp.mikio.mobilelinelogger.v1/files/logs/`。
